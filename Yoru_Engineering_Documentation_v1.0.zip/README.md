# Yoru

Engineering blueprint untuk marketplace beauty commerce dan home service berbasis AI.

> Status: **documentation-first / pre-implementation**. Repository aplikasi belum
> di-scaffold. Dokumen ini adalah acuan bersama sebelum source code dibuat.

## 1. Ringkasan produk

Yoru menghubungkan:

- customer yang membeli skincare, fashion, aksesori styling, dan memesan home service;
- partner/UMKM yang menjual produk atau layanan;
- profesional yang melakukan treatment, barber, salon, atau layanan dental yang diizinkan;
- tim platform yang memverifikasi partner, mengawasi transaksi, menangani sengketa, dan
  mengelola payout.

Platform mengambil komisi awal sekitar **10%** dari eligible subtotal. Formula final,
aturan refund, biaya payment gateway, pajak, dan payout harus dikunci melalui
[decision register](docs/07-roadmap-decisions.md) sebelum modul ledger dibuat.

AI Yoru memiliki dua tanggung jawab:

1. **Customer Advisor** — rekomendasi produk atau layanan berdasarkan kebutuhan, budget,
   preferensi, teks, dan foto dengan persetujuan eksplisit.
2. **Partner Copilot** — menjelaskan performa omzet, penjualan, booking, inventory, dan
   tindakan peningkatan bisnis berdasarkan metrik yang dihitung secara deterministik.

AI tidak boleh melakukan diagnosis medis. Treatment invasif dan dental invasif berada di
luar MVP sampai ada validasi legal dan klinis.

## 2. Arsitektur target

```mermaid
flowchart TB
    Customer["Customer"] --> Storefront["Next.js Storefront"]
    Partner["Partner, Professional, Admin"] --> Console["Next.js Console"]
    Storefront --> API["FastAPI Modular Monolith"]
    Console --> API
    API --> PG[("PostgreSQL")]
    API --> Redis[("Redis")]
    API --> Qdrant[("Qdrant")]
    API --> ObjectStore[("Object Storage")]
    API --> Providers["Payment, Maps, Logistics, Messaging, AI"]
    Worker["Worker"] --> PG
    Worker --> Redis
    Worker --> Qdrant
    Worker --> Providers
```

Prinsip utama:

- dua aplikasi Next.js dalam satu monorepo: `storefront` dan `console`;
- satu FastAPI modular monolith pada fase awal, dipisahkan berdasarkan domain;
- worker menjalankan tugas asinkron, outbox, notifikasi, indexing, dan AI jobs;
- PostgreSQL adalah system of record;
- Redis tidak menyimpan data bisnis yang tidak dapat direkonstruksi;
- Qdrant adalah vector database, bukan model AI atau sumber kebenaran;
- `partner_id` adalah batas tenant pada database, cache, object storage, dan payload Qdrant;
- transaksi produk dan booking layanan memakai state machine terpisah;
- ledger bersifat immutable dan reversal dibuat sebagai entry baru.

Detail: [Engineering Overview](docs/00-engineering-overview.md).

## 3. Struktur repository yang akan dibuat

```text
yoru/
├── apps/
│   ├── storefront/          # Customer ecommerce + booking
│   └── console/             # Partner, professional, admin
├── services/
│   ├── api/                 # FastAPI modular monolith
│   └── worker/              # Async jobs dan outbox consumers
├── packages/
│   ├── ui/                  # Shared React components dan tokens
│   ├── contracts/           # Generated API types/client
│   ├── config/              # ESLint, TypeScript, Tailwind
│   └── observability/       # Logging, tracing, error helpers
├── infra/
│   ├── compose/
│   ├── migrations/
│   └── monitoring/
├── openapi/
├── docs/
├── tests/
│   ├── contract/
│   ├── e2e/
│   ├── performance/
│   └── security/
├── .env.example
├── CONTRIBUTING.md
└── README.md
```

Struktur di atas adalah target. Jangan membuat microservice baru tanpa ADR dan bukti
bahwa batas modular monolith sudah menjadi bottleneck.

## 4. Stack dan aturan versi

| Area | Pilihan |
| --- | --- |
| Frontend | Next.js App Router, React, TypeScript strict |
| Backend | Python, FastAPI, Pydantic, SQLAlchemy async, Alembic |
| Database | PostgreSQL |
| Cache/job coordination | Redis |
| Vector retrieval | Qdrant |
| File | S3-compatible object storage |
| API | REST `/api/v1`, OpenAPI 3.1 |
| Auth | Secure cookie session + rotating refresh token; MFA untuk role sensitif |
| Testing | Pytest, Vitest, Testing Library, Playwright, k6, security scans |
| Observability | OpenTelemetry-compatible traces, structured logs, metrics, error tracking |

Versi runtime dan dependency harus dipin di lockfile/image digest ketika scaffold dibuat.
Jangan menyalin versi dari dokumentasi ini ke production tanpa dependency review.

## 5. Peran dan isolasi akses

Peran utama:

- `customer`
- `partner_owner`
- `partner_admin`
- `partner_finance`
- `professional`
- `platform_super_admin`
- `platform_verifier`
- `platform_support`
- `platform_finance`

Otorisasi menggunakan kombinasi:

1. **RBAC** untuk capability dasar;
2. **ABAC** untuk kepemilikan resource, status, dan wilayah;
3. **tenant scope** berdasarkan `partner_id`;
4. **PostgreSQL Row-Level Security** sebagai defense in depth;
5. audit log untuk seluruh tindakan sensitif.

Lihat [Auth & Security](docs/03-auth-security.md) dan
[Status & Permission Matrix](docs/08-status-permissions.md).

## 6. Urutan implementasi wajib

### Foundation Gate

Tidak boleh masuk ke pengembangan katalog, checkout, booking, atau AI sebelum semua item
berikut lulus:

- struktur monorepo dan quality tooling;
- environment validation;
- migration baseline;
- register, login, logout, refresh, revoke session;
- RBAC, ABAC, tenant scope, dan pengujian IDOR/BOLA;
- audit log untuk auth dan perubahan role;
- health, readiness, structured logging, request ID;
- CI untuk lint, type-check, unit, migration, dan integration test;
- secret scanning dan dependency scanning.

### Urutan domain

1. Identity, partner onboarding, verification.
2. Catalog, inventory, service, professional, availability.
3. Cart, checkout, payment webhook, order.
4. Booking, dispatch, tracking, OTP check-in/out.
5. Ledger, commission, refund, payout, dispute.
6. Customer AI Advisor.
7. Partner AI Copilot.
8. Hardening, performance, compliance, dan scale testing.

Backlog rinci: [Roadmap & Decision Register](docs/07-roadmap-decisions.md).

## 7. Development workflow target

Setelah scaffold tersedia:

```bash
corepack enable
pnpm install
docker compose up -d postgres redis qdrant
pnpm dev
```

Backend:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r services/api/requirements-dev.txt
alembic upgrade head
uvicorn app.main:app --reload
```

Command di atas adalah kontrak developer experience yang harus diwujudkan pada Sprint 0;
saat ini belum dapat dijalankan karena source code belum dibuat.

## 8. Konfigurasi

Gunakan `.env.example` sebagai daftar kontrak konfigurasi. Aturan:

- tidak ada secret asli dalam Git;
- frontend hanya menerima environment variable berawalan `NEXT_PUBLIC_` jika memang aman
  dikirim ke browser;
- backend gagal start bila konfigurasi wajib tidak valid;
- production menggunakan secret manager;
- kunci webhook, refresh-token signing key, dan encryption key memiliki prosedur rotasi.

## 9. Kontrak API

- Base path: `/api/v1`
- Media type: `application/json`
- Error: `application/problem+json`
- Timestamp: UTC ISO 8601
- Money: integer dalam minor unit + kode mata uang
- Pagination: cursor untuk feed/transaksi besar; offset hanya untuk tabel admin terbatas
- Mutasi kritis: `Idempotency-Key`
- Trace: `X-Request-ID`
- Concurrency: version field atau `If-Match`

Lihat [API Contract](docs/02-api-contract.md) dan
[OpenAPI outline](openapi/yoru-api-outline.yaml).

## 10. Data dan performa

- setiap tabel tenant-owned memiliki `partner_id`;
- foreign key, unique constraint, check constraint, dan state transition divalidasi di DB;
- index dibuat berdasarkan query nyata, bukan semua kolom;
- pattern index awal: `(partner_id, status, updated_at DESC, id DESC)`;
- gunakan keyset pagination pada order, booking, ledger, dan audit log;
- cache-aside hanya untuk data read-heavy yang dapat direkonstruksi;
- invalidasi cache terjadi setelah commit/outbox;
- `useMemo` hanya untuk komputasi mahal yang terukur;
- debounce 300–500 ms untuk pencarian; request lama harus dibatalkan;
- hindari N+1, unbounded query, offset dalam, dan payload berlebihan.

## 11. Dokumentasi

| Dokumen | Fungsi |
| --- | --- |
| [Engineering Overview](docs/00-engineering-overview.md) | Batas sistem, modul, dependency, dan struktur code |
| [Domain & Data Model](docs/01-domain-data-model.md) | Aggregate, tabel, ERD, invariants, indexing |
| [API Contract](docs/02-api-contract.md) | Aturan API, endpoint inventory, errors, idempotency |
| [Auth & Security](docs/03-auth-security.md) | Session, authorization, threat controls, privacy |
| [AI System](docs/04-ai-system.md) | Retrieval, tools, guardrails, evaluasi, fallback |
| [Development & Testing](docs/05-development-testing.md) | Coding standards, testing strategy, CI gates |
| [DevOps & Observability](docs/06-devops-observability.md) | Environment, deployment, SLO, backup, incident |
| [Roadmap & Decisions](docs/07-roadmap-decisions.md) | Sprint, backlog, keputusan terbuka |
| [Status & Permissions](docs/08-status-permissions.md) | State machine dan matriks akses |
| [References](docs/references.md) | Sumber teknis dan keamanan |
| [Contributing](CONTRIBUTING.md) | Branch, commit, PR, review, Definition of Done |

## 12. Aturan non-negotiable

- Jangan mempercayai `partner_id`, role, harga, komisi, atau total dari browser.
- Jangan menyimpan raw payment card data.
- Jangan memasukkan foto wajah, data kesehatan, token, atau PII ke log.
- Jangan memasukkan raw foto ke Qdrant.
- Jangan menggunakan output LLM sebagai angka finansial sumber kebenaran.
- Jangan menghapus ledger entry; gunakan reversal.
- Jangan menandai pembayaran berhasil hanya dari redirect browser.
- Jangan mencampur status fulfillment produk dengan status booking layanan.
- Jangan deploy migration destruktif tanpa expand–migrate–contract.
- Jangan mengaktifkan layanan dental/treatment invasif sebelum legal/clinical gate.

## 13. Definition of Ready untuk mulai coding

Coding Sprint 0 dapat dimulai setelah product owner menyetujui:

- formula komisi dan payout;
- aturan cross-partner cart;
- scope layanan treatment/dental;
- booking acceptance dan service area;
- cancellation/no-show/refund;
- retensi foto dan data sensitif;
- provider payment, maps, logistics, messaging, object storage, dan AI.

Keputusan yang belum final harus berada di feature flag dan tidak boleh disamarkan sebagai
requirement final.
