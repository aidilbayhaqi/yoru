export const PLATFORM_ROLES = [
  "customer",
  "partner_owner",
  "partner_admin",
  "partner_finance",
  "professional",
  "platform_super_admin",
  "platform_verifier",
  "platform_support",
  "platform_finance",
] as const;

export type PlatformRole = (typeof PLATFORM_ROLES)[number];

export type HealthStatus = "ok" | "degraded" | "unavailable";

export interface DependencyHealth {
  status: HealthStatus;
  latency_ms?: number;
}

export interface HealthResponse {
  status: HealthStatus;
  service: string;
  version: string;
  request_id: string;
  dependencies?: Record<string, DependencyHealth>;
}

export interface ProblemDetails {
  type: string;
  title: string;
  status: number;
  code: string;
  detail?: string;
  instance?: string;
  request_id: string;
}
