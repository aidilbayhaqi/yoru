# Yoru Platform

Sprint 0 engineering foundation untuk Yoru: dua aplikasi Next.js, FastAPI modular
monolith, worker, PostgreSQL, Redis, dan Qdrant.

## Status

Yang sudah tersedia:

- `apps/storefront` pada port `3000`;
- `apps/console` pada port `3001`;
- `services/api` pada port `8000`;
- `services/worker`;
- Docker Compose untuk PostgreSQL, Redis, Qdrant, API, worker, storefront, dan console;
- environment validation;
- request ID, JSON logs, security headers, CORS allowlist, dan problem details;
- liveness/readiness/startup endpoints;
- Alembic baseline;
- frontend/backend unit tests;
- GitHub Actions dan Dependabot.

Belum tersedia pada Sprint 0:

- authentication dan tenant authorization;
- partner onboarding;
- catalog, inventory, order, booking, payment, ledger;
- AI Customer Advisor dan Partner Copilot.

Modul bisnis tersebut baru dimulai setelah foundation gate lulus.

## Struktur

```text
apps/
  storefront/
  console/
packages/
  contracts/
  ui/
services/
  api/
  worker/
docs/
openapi/
scripts/
```

## Prasyarat

- Node.js 24+
- pnpm 11+
- Python 3.12+
- Docker Desktop/Engine dengan Compose

## Menjalankan local

Salin environment:

```bash
cp .env.example .env
```

Install:

```bash
corepack enable
pnpm install
python -m venv .venv
```

Linux/macOS:

```bash
.venv/bin/python -m pip install -e "services/api[dev]" -e "services/worker[dev]"
```

Windows PowerShell:

```powershell
.\.venv\Scripts\python.exe -m pip install -e "services/api[dev]" -e "services/worker[dev]"
```

Jalankan semua service:

```bash
docker compose up --build
```

Atau hanya infrastructure:

```bash
docker compose up -d postgres redis qdrant
```

Kemudian jalankan frontend, API, dan worker dari terminal terpisah:

```bash
pnpm dev
.venv/bin/uvicorn yoru_api.main:app --app-dir services/api/src --reload --port 8000
.venv/bin/python -m yoru_worker.main
```

## Endpoint awal

| Endpoint              | Tujuan                             |
| --------------------- | ---------------------------------- |
| `GET /`               | Metadata service                   |
| `GET /api/v1/meta`    | Kontrak API foundation             |
| `GET /health/live`    | Process hidup                      |
| `GET /health/ready`   | PostgreSQL, Redis, dan Qdrant siap |
| `GET /health/startup` | Konfigurasi/startup selesai        |
| `GET /docs`           | Swagger UI saat non-production     |

## Quality gate

```bash
pnpm lint
pnpm typecheck
pnpm test
pnpm build

.venv/bin/ruff check services
.venv/bin/mypy services/api/src services/worker/src
.venv/bin/pytest services/api/tests services/worker/tests
```

Gunakan `make check` pada Linux/macOS setelah `.venv` tersedia.

## Migration

```bash
.venv/bin/alembic -c services/api/alembic.ini upgrade head
```

Migration production harus forward-only dan backward-compatible.

## Kontrak keamanan

- Browser tidak menjadi sumber authority untuk role, tenant, harga, komisi, atau total.
- CORS menggunakan allowlist eksplisit.
- Secret production tidak boleh berada di `.env` repository.
- Log tidak boleh memuat token, password, OTP, foto, alamat lengkap, atau PII sensitif.
- Endpoint readiness tidak membocorkan credential/hostname internal.
- Authentication Sprint 1 wajib menggunakan secure HttpOnly cookie, refresh rotation,
  MFA role sensitif, RBAC + ABAC + tenant scope + PostgreSQL RLS.

## Dokumentasi

Lihat folder `docs/` untuk PRD engineering, data model, API, security, AI, testing,
DevOps, roadmap, state machine, dan permission matrix.

Hasil quality gate terakhir tersedia di
[`docs/VALIDATION_REPORT.md`](docs/VALIDATION_REPORT.md).
