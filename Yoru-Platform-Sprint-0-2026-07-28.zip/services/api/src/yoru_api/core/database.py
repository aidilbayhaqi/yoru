from sqlalchemy.ext.asyncio import AsyncEngine, create_async_engine

from yoru_api.core.settings import Settings


def create_database_engine(settings: Settings) -> AsyncEngine:
    return create_async_engine(
        settings.database_url,
        pool_pre_ping=True,
        pool_size=settings.database_pool_size,
        max_overflow=settings.database_max_overflow,
    )
